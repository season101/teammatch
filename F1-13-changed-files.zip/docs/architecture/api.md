# API Contract

One origin serves everything: `https://teammatch.sijancodes.com` in prod, `http://localhost:3000` locally (Next.js rewrites `/api`, `/_allauth`, `/ws` to the api container in dev). No CORS.

The source of truth is the OpenAPI schema, not this page. This page is the overview.

## Conventions

| Topic | Rule |
|---|---|
| Base path | `/api/v1/` |
| Format | JSON, `snake_case` fields, ISO 8601 UTC timestamps |
| Auth | Session cookie from allauth headless (`browser` client). Unsafe methods need the `X-CSRFToken` header. Future mobile app sends `X-Session-Token` (`app` client). |
| Authz | Every object endpoint checks ownership or membership. Objects the user cannot see return `404`. Acting on something you can see but don't own returns `403` (for example editing someone else's profile). |
| IDs | Integer ids in paths |
| Trailing slash | Always (`/api/v1/projects/`) |

## Versioning

- The version is in the path (`/api/v1/`). Additive changes (new fields, new endpoints) stay in v1.
- Breaking changes (removing or renaming a field, changing meaning) need `/api/v2/` for that resource and an ADR. For a class project we expect to stay on v1.
- WS messages carry a `type` field; new types are additive, clients ignore unknown types.

## OpenAPI and the generated client

- drf-spectacular serves the live schema at `/api/schema/` and Swagger UI at `/api/docs/` (docs UI is staff-only in prod).
- `make schema` writes `backend/schema.yml`, which is committed.
- `make client` regenerates `packages/api-client` from `backend/schema.yml` with `openapi-typescript` + `openapi-fetch`.
- CI regenerates both and fails on `git diff`, so the schema, the client and the code cannot drift.

## Errors

> Not built yet. Today the API returns Django REST Framework's default bodies: `{ "detail": "..." }`, or `{ "field": ["..."] }` for validation errors. The `code` values in the table below are raised by the backend, for example `project_locked`, but they are not in the response body yet. The shape below is the target.

All `/api/v1/` errors use one shape (custom DRF exception handler in `core`):

```json
{
  "error": {
    "code": "validation_error",
    "message": "Some fields are invalid.",
    "fields": {
      "title": ["This field is required."]
    }
  }
}
```

| Status | `code` examples | When |
|---|---|---|
| 400 | `validation_error`, `invalid_avatar` | bad input |
| 401 | `not_authenticated` | no session |
| 403 | `permission_denied`, `profile_retired`, `own_project` | logged in but not allowed |
| 404 | `not_found` | missing or not visible to you |
| 409 | `already_applied`, `role_not_open`, `already_on_team`, `project_locked` | state conflict |
| 429 | `throttled` | rate limit |
| 500 | `server_error` | bug, no details leaked |

allauth endpoints keep allauth's own response format (`status`, `errors`, `data`, `meta`); the frontend auth feature handles that separately.

## Pagination

- Lists use cursor pagination: `?cursor=<opaque>&page_size=20` (max 50).
- Response:

```json
{ "next": "https://.../?cursor=abc", "previous": null, "results": [] }
```

- Feed and chat history are cursor-only. Small admin-ish lists (skills, terms) are not paginated.

## Endpoints

Rows marked **(planned)** are the contract for stories that are not built yet. They are not in `backend/schema.yml`, and a request to them returns `404` today. Every other row matches the schema.

### core

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/healthz` | none | liveness, no dependencies |
| GET | `/readyz` | none | readiness, checks db + redis |
| GET | `/api/v1/health/` | none | same checks as `/readyz`; always `200`, the body says whether db and redis are healthy |
| GET | `/api/v1/terms/` | user | list terms **(planned)** |
| GET | `/api/v1/terms/current/` | user | current term **(planned)** |

### accounts

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/v1/me/` | user | current user + profile summary **(planned)** |
| DELETE | `/api/v1/me/` | user | deactivate own account (future, F1-09) |

Login, signup, logout, password and Google live under allauth (below).

### profiles

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/v1/me/profile/` | user | own profile |
| PATCH | `/api/v1/me/profile/` | user | update display name, bio, major, skills |
| POST | `/api/v1/me/avatar/` | user | upload avatar as `multipart/form-data` (JPEG/PNG/WebP, max 2 MB); API saves it to SeaweedFS via django-storages **(planned)** |
| DELETE | `/api/v1/me/avatar/` | user | remove avatar **(planned)** |
| GET | `/api/v1/profiles/{id}/avatar/` | user | avatar image, streamed by the API from SeaweedFS **(planned)** |
| GET | `/api/v1/profiles/{id}/` | user | public profile view |
| PATCH | `/api/v1/profiles/{id}/` | owner | edit your own profile by id (`403` for anyone else) |
| GET | `/api/v1/skills/?q=` | user | filter skills by name for pickers |
| POST | `/api/v1/skills/` | user | add a new skill (deduped by name) **(planned)** |

### projects

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/v1/projects/` | user | open projects, cursor-paginated. `?q=` searches title, pitch, open role titles and their required skills, ignoring case (F2-07). The `term`, `skill` and `status` filters are **(planned)** |
| POST | `/api/v1/projects/` | user | create project (draft) |
| GET | `/api/v1/projects/mine/` | user | projects I own |
| GET | `/api/v1/projects/{id}/` | user | project detail with roles |
| PATCH | `/api/v1/projects/{id}/` | owner | edit title, pitch |
| DELETE | `/api/v1/projects/{id}/` | owner | delete draft **(planned)** |
| POST | `/api/v1/projects/{id}/publish/` | owner | draft to open |
| POST | `/api/v1/projects/{id}/close/` | owner | archive |
| POST | `/api/v1/projects/{id}/roles/` | owner | add role |
| PATCH | `/api/v1/roles/{id}/` | owner | edit role, required skills |
| DELETE | `/api/v1/roles/{id}/` | owner | delete open role (may trigger lock) |

### matching

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/v1/feed/` | user | swipe deck, open roles ranked by match % (share of the role's required skills I have), then newest. Empty while I'm retired |
| POST | `/api/v1/feed/reset/` | user | clear my passes so those roles come back into my feed, `204`. Applied roles stay out |
| POST | `/api/v1/roles/{id}/dismiss/` | user | candidate pass on a role, `204`; repeats are fine. My own project: `403`; role or project not open: `409` |
| DELETE | `/api/v1/roles/{id}/dismiss/` | user | take back my pass on a role, `204`, also when there was none. Only my own pass |
| POST | `/api/v1/applications/` | user | apply to a role `{role, note}`. Retired: `403` `profile_retired`. Committed this term: `409` `applicant_committed` |
| GET | `/api/v1/applications/mine/?status=` | user | my applications |
| POST | `/api/v1/applications/{id}/withdraw/` | applicant | withdraw pending application |
| GET | `/api/v1/roles/{id}/applications/?status=` | owner | pending applicants for a role, minus retired ones, best `match_percent` first then oldest (`403` if it's not your project). `?status=liked` lists offers out, `?status=committed` who took the seat |
| POST | `/api/v1/applications/{id}/like/` | owner | like: sends an offer, the role stays open (F4-10). Applicant on a team or committed: `409` |
| POST | `/api/v1/applications/{id}/commit/` | applicant | take the seat an offer is for: fills the role, closes my other applications this term, may lock the team. `409` `offer_not_open`, `role_not_open`, `owns_open_project` or `applicant_committed`; someone else's: `403` |
| POST | `/api/v1/applications/{id}/decline/` | applicant | turn an offer down; the role stays open. Not an open offer: `409` |
| POST | `/api/v1/applications/{id}/pass/` | owner | pass |
| GET | `/api/v1/teams/mine/` | user | my team this term with my `seen_at`: `{"team": {id, project {id, title}, term {name, end_date}, members [{display_name, role}], formed_at, seen_at}}`. `role` is the role title, or `"Owner"`. `formed_at` is when the team locked. No team this term: `200` with `{"team": null}` |
| GET | `/api/v1/teams/{id}/` | member | team detail with members and roles **(planned)** |
| POST | `/api/v1/teams/{id}/seen/` | member | mark the "It's a Team!" screen as seen, `204`. Sets my `seen_at` the first time; repeats keep it. Not my team: `404` |

### chat

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/v1/teams/{id}/messages/?cursor=&after=` | member | chat history, newest first, 50 a page: `{id, team, sender {id, display_name}, body, created_at}`. `after=<message id>` keeps only newer messages (catch-up after a reconnect) and stays in the `next` link; not an integer: `400`. Not on the team or no such team: `404` |

Sending messages is WS only.

### Admin and static

| Path | Purpose |
|---|---|
| `/admin/` | Django admin, staff only |
| `/static/` | Django static files (admin, DRF), served by WhiteNoise |

## allauth headless

Two clients, same backend:

| Client | Prefix | Used by | Session |
|---|---|---|---|
| browser | `/_allauth/browser/v1/` | Next.js PWA | session cookie + CSRF |
| app | `/_allauth/app/v1/` | future Expo app | `X-Session-Token` header |

Endpoints we use (same under both prefixes):

| Method | Path | Purpose |
|---|---|---|
| GET | `config` | available providers, signup open |
| POST | `auth/signup` | email signup |
| POST | `auth/login` | email login; a Google account with no password gets 400 `google_only_account` instead of the usual mismatch (F1-13, DD-37) |
| GET | `auth/session` | who am I |
| DELETE | `auth/session` | logout |
| POST | `auth/email/verify` | verify email key |
| POST | `auth/password/request` | password reset email |
| POST | `auth/password/reset` | set new password with key |
| POST | `auth/provider/redirect` | start Google login (browser form POST) |
| POST | `auth/provider/token` | Google id_token login (app client) |
| GET | `account/providers` | linked sign-in providers (Settings, F1-12) |
| POST | `account/password/change` | signed in: set a password; with no password yet, just `new_password` (F1-12) |

`auth/provider/redirect` with `process: "connect"` and `callback_url: "/settings"` links Google to the signed-in account. The Google email has to match the account's, or it comes back as `/settings?error=google_email_mismatch` (F1-12, DD-36).

Domain allowlist (`ALLOWED_EMAIL_DOMAINS`) is enforced in the account and social adapters for all of them. Google sign-ins must also come from LA Tech's Google Workspace, and Google's redirect returns to `/accounts/google/login/callback/`, outside `/_allauth` ([Google Sign-In](google-sign-in.md)).

## WebSocket

| Path | Auth | Purpose |
|---|---|---|
| `/ws/teams/{id}/` | session cookie, must be team member | team chat |
| `/ws/notifications/` | session cookie | per-user events (liked, team formed). **Future (F3-07), not in the MVP.** |

The MVP only builds `/ws/teams/{id}/` for chat. `/ws/notifications/` and its events are kept here as the future contract.

Handshake: same origin, cookie sent automatically. Origin is checked (`AllowedHostsOriginValidator`). Close codes: `4401` not logged in, `4404` team not found or not a member (same answer, so team ids do not leak).

### Message envelope

Every frame is JSON:

```json
{ "type": "string", "data": {} }
```

### Client to server

| `type` | `data` | Notes |
|---|---|---|
| `chat.send` | `{ "body": "string, 1-2000 chars", "client_id": "uuid" }` | `client_id` lets the sender match the echo |
| `ping` | `{}` | keepalive, server replies `pong` |

### Server to client

| `type` | `data` |
|---|---|
| `chat.message` | `{ "id": 1, "team": 3, "sender": { "id": 7, "display_name": "..." }, "body": "...", "created_at": "2026-10-30T18:00:00Z", "client_id": "uuid or null" }` |
| `chat.error` | `{ "code": "validation_error", "message": "...", "client_id": "uuid or null" }` |
| `application.liked` | `{ "application": 12, "role": 4, "project": 2 }` (future, `/ws/notifications/`) |
| `team.formed` | `{ "team": 3, "project": 2 }` (future, `/ws/notifications/`) |
| `pong` | `{}` |

`packages/api-client/ws.ts` has TypeScript types for the chat socket frames and close codes. Any change to the chat rows above updates that file in the same PR.

## Rate limits

DRF throttles: `apply` 60/hour per user, `chat.send` 30/10s per connection **(planned)**, anonymous auth endpoints 20/min per IP.
